let message = document.getElementById("loginButton").innerText;
function buttonUpdate(){
    if (message == "Login"){
        message = "Logout"} else {message = "Login"}}
 }

function disappear{
    let element = document.getElementById(this);
    element.remove();
}

let product = 1
for (let i = 0; i<12;i++){
  product =(product *i)*product
  console.log(i)
}
console.log(product)

let sum = 0
for (let i = 0; i<101;i++){
  sum =+ sum +i
  console.log(i)
}
console.log(sum)

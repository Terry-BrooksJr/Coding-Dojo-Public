for (var i=0;i<21;i++){
  if (i % 2 != 0){
    console.log(i);
  }
}

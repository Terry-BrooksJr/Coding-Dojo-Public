for(let i=0;i<=5;i++){
  if (i == 0){
    console.log(4)
  }if (i==1) {
    console.log(2.5)
  }if (i==2){
    console.log(1)
  } if (i==3){
    console.log(-0.5)
  }if (i==4){
    console.log(-2)
  }if (i==5) {
    console.log(-3.5)
  }
}
